import React, { Component } from 'react';
import AppHeader from '../components/global/AppHeader';
import AppFooter from '../components/global/AppFooter';
import ServiceTile from './ServiceTile.js';
import basic from './theme/images/basic.png';
import enhanced from './theme/images/enhanced.png';
import primium from './theme/images/primium.png'

class ServicesPackages extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 'neo'
    }
    this.onTabChange = this.onTabChange.bind(this);
  }

  onTabChange(tab) {
    this.setState({ activeTab: tab });
  }
	render() {
    console.log(this.state.activeTab);
		return(			
		   <div>
			  <AppHeader userFullName="Admin" />
        <div className='navigation-bar'>Services >> Neo Content Suits</div>
			  <div className="app-body-plans " style={{height:"600px"}}>
				<div id = "leftPane"style={{float:"left",backgroundColor:"#777777",height:"800px"}}>
                  <ul style = {{paddingLeft: "10px"}}>
                    <li style = {{listStyle : "none",fontWeight:"bold",padding:"10px",height :"40px",borderBottom: "1px solid #2a2a2a",cursor: "pointer"}}><a onClick={(event) => this.onTabChange('neo')}>Neo Standard Packages</a></li>
                    <li style = {{listStyle: "none",fontWeight:"bold",padding:"10px",borderBottom: "1px solid #2a2a2a",cursor: "pointer"}} onClick={(event) => this.onTabChange('plan')}><a>MyActive Plans</a></li>
                  </ul>
                </div>
                <div id = "rightPane"style={{}}>
                {this.state.activeTab === 'neo' ? <div className="ServicesTiles" style={{display : "inline-flex",width:"980px",height:"400px"}}>
				<div className ="childElements">
        <div className = "child"style={{height: "450px"}}>
        <h3 style = {{textAlign:"center",fontWeight: "bold",color: "#167dc7"}}>Neo Model Standard Packages</h3>
        <table className = "packagesPlans"style={{width: "980px",marginTop: "10px",marginLeft: "10px",border: "1px solid #E4E4E4",textAlign: "center"}}>
				 <tbody>
                 <tr style={{border: "1px"}}>
                     <th style={{border: "1px solid #E4E4E4",textAlign: "center",
    color: "#167dc7",fontSize: "20px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}>Parameter</th>
					
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={basic} name={"Basic"} description={""} /></th> 
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={enhanced} name={"Enhanced"} description={""}/></th>
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={primium} name={"Premium"} description={""} /></th>
    
					 </tr>
                    <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Users (Named)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Upto 3,000 with 5% concurrency</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Upto 5,000 (5% concurrency)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Upto 10,000 (5% concurrency)</td>
                    </tr>
                    <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Storage</td>
                    <td style={{border: "1px solid #E4E4E4"}}>5 TB</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>20 TB</td>
                    <td style={{border: "1px solid #E4E4E4"}}>50 TB</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Number Of Documents managed</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 10 Mn</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>10 Mn to 25 Mn</td>
                    <td style={{border: "1px solid #E4E4E4"}}>25 Mn to 40 Mn</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Support Window</td>
                    <td style={{border: "1px solid #E4E4E4"}}>8 X 5 </td> 
                    <td style={{border: "1px solid #E4E4E4"}}>24 X 5 </td>
                    <td style={{border: "1px solid #E4E4E4"}}>24 X 7 </td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Supported Language</td>
                    <td style={{border: "1px solid #E4E4E4"}}>English</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>English</td>
                    <td style={{border: "1px solid #E4E4E4"}}>English</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Timezone</td>
                    <td style={{border: "1px solid #E4E4E4"}}>1</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>All</td>
                    <td style={{border: "1px solid #E4E4E4"}}>All</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Onsite Support (Local)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>-</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>-</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Available (Optional)</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>On Call Support</td>
                    <td style={{border: "1px solid #E4E4E4"}}>-</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>Included</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Included</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Count of Environment Set (Prod, UAT, QA, Dev)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>1</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>1</td>
                    <td style={{border: "1px solid #E4E4E4"}}>2</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Service Request Included (per month)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>30</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>50</td>
                    <td style={{border: "1px solid #E4E4E4"}}>70</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Coordination With Product Vendor</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Included</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>Included</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Included</td>
                  </tr>
                  <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>ECM Application (OOTB)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>1</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 3</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 5</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Applications Integration Supported</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 2</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 4</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Up to 5</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Application Size (As per Service Catalog)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Size – Extra Small OR Small</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>+ Up to 1 Medium</td>
                    <td style={{border: "1px solid #E4E4E4"}}>+ Up to 1 Large</td>
                  </tr>
                  <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>HApps</td>
                    <td style={{border: "1px solid #E4E4E4"}}>HApps (Basic)</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>HApps (Enhanced)</td>
                    <td style={{border: "1px solid #E4E4E4"}}>HApps (Premium)</td>
                  </tr>
				  </tbody>
                 </table>
				 </div>
                 <div className = "addOns">
				 <h3 style = {{textAlign:"center",fontWeight: "bold",color: "#167dc7"}}>Add Ons</h3>
                 <table style={{width:"99%",marginLeft: "10px",border: "1px solid #E4E4E4"}}>
				 <tbody>
                 <tr>
                   <th style={{border: "1px solid #E4E4E4",textAlign: "center",
    color: "#167dc7",fontSize: "20px",width:"33%",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}>Parameter</th>
                    <th style={{border: "1px solid #E4E4E4",textAlign: "center",
    color: "#167dc7",fontSize: "20px",width:"24%",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}>Basic</th>
                    <th style={{border: "1px solid #E4E4E4",textAlign: "center",
    color: "#167dc7",fontSize: "20px",width:"21%",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}>Enhanced</th>
                   <th style={{border: "1px solid #E4E4E4",textAlign: "center",
    color: "#167dc7",fontSize: "20px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}>Premium</th>
                    </tr>
                    <tr>
                    <td style={{border: "1px",border: "1px solid #E4E4E4",textAlign: "-webkit-center"}}>Pages</td>
                    <td style={{border: "1px",border: "1px solid #E4E4E4",textAlign: "-webkit-center"}}>Up To 1 Mn per Year</td> 
                    <td style={{border: "1px",border: "1px solid #E4E4E4",textAlign: "-webkit-center"}}>Up To 1.5 Mn per Year</td>
                    <td style={{border: "1px",textAlign: "-webkit-center"}}>Up To 10 Mn per Year</td>
                    </tr>
                    
				  </tbody>
                 </table>
                 </div>
                 <div className = "child"style={{height: "450px"}}>
        <h3 style = {{textAlign:"center",fontWeight: "bold",color: "#167dc7"}}>Neo Applications</h3>
        <table className = "packagesPlans"style={{width: "980px",marginTop: "10px",marginLeft: "10px",border: "1px solid #E4E4E4",textAlign: "center"}}>
				 <tbody>
                 <tr style={{border: "1px"}}>
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={basic} name={"Basic"} description={""} /></th> 
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={enhanced} name={"Enhanced"} description={""}/></th>
                    <th style={{border: "1px solid #E4E4E4",paddingTop: "10px",backgroundColor: "#d4d2d2",
    textAlign: "-webkit-center"}}><ServiceTile icon={primium} name={"Premium"} description={""} /></th>
    
					 </tr>
                    <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Dashboard</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Dashboard</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Dashboard</td>
                    </tr>
                    <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}>Integration Framework Built-In
</td> 
                    <td style={{border: "1px solid #E4E4E4"}}>Integration Framework Built-In
</td>
                    <td style={{border: "1px solid #E4E4E4"}}>Integration Framework Built-In
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>DevOps
</td>
                    <td style={{border: "1px solid #E4E4E4"}}>DevOps
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                     <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}>HA for Production
</td>
                    <td style={{border: "1px solid #E4E4E4"}}>SDK
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                     <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>HA for Production
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                   <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Capacity Planning Dashboard
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Object Model Templates
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Patch Automation
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Connectors</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                     <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Bulk Upload Tool
</td>
                  </tr>
                  <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Upgrades Components
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Migration Connector
</td>
                  </tr>
                   <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td> 
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>DR Test
</td>
                  </tr>
                  <tr style={{border: "1px solid #E4E4E4"}}>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}></td>
                    <td style={{border: "1px solid #E4E4E4"}}>Infra - Command Centre
</td>
                  </tr>
				  </tbody>
                 </table>
				 </div></div></div> : null}
                {this.state.activeTab === 'plan' ? <span>Active plans</span>: null}
                 
                </div>
			 </div>
			 <AppFooter />				
		  </div>
		);
	}
}

export default ServicesPackages;